package com.mongo_blog.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
